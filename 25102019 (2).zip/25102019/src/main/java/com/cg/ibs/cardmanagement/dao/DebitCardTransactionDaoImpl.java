package com.cg.ibs.cardmanagement.dao;


import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class DebitCardTransactionDaoImpl implements DebitCardTransactionDao {
	
	
	
	

	private EntityManager entityManager;

	public DebitCardTransactionDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
	}
	@Override
	public boolean verifyDebitTransactionId(String transactionId) throws IBSException {
		boolean result = false;
/*
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.VERIFY_DEBIT_TRANS_ID);) {
			preparedStatement.setString(1, transactionId);

			try (ResultSet resultSet = preparedStatement.executeQuery();) {

				if (resultSet.next()) {

					result = true;
				}

			}
		} catch (Exception e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}*/

		return result;
	}

	@Override
	public List<DebitCardTransaction> getDebitTrans(int days, BigInteger debitCardNumber) throws IBSException {
		List<DebitCardTransaction> debitCardsList = new ArrayList<>();


		return debitCardsList;
	}

	@Override
	public BigInteger getDMUci(String transactionId) throws IBSException {

		BigInteger debitCardUci = null;
	/*	try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.GET_DM_UCI)) {
			preparedStatement.setString(1, transactionId);

			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				while (resultSet.next()) {

					debitCardUci = resultSet.getBigDecimal("UCI").toBigInteger();

				}

			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);

			}
		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}*/
		return debitCardUci;

	}

	@Override
	public BigInteger getDebitCardNumber(String transactionId) throws IBSException {
		TypedQuery<DebitCardTransaction> debitQuery = entityManager.createQuery("Select ",
				DebitCardTransaction.class);
	
		

		return debitCards;
	}

}
