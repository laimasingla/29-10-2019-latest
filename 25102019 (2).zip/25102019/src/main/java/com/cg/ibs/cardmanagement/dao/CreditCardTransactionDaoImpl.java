package com.cg.ibs.cardmanagement.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CreditCardTransactionDaoImpl implements CreditCardTransactionDao {

	@Override
	public boolean verifyCreditTransactionId(String transactionId) throws IBSException {
		boolean result = false;

	/*	try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.VERIFY_CREDIT_TRANS_ID);) {
			preparedStatement.setString(1, transactionId);

			try (ResultSet resultSet = preparedStatement.executeQuery();) {

				if (resultSet.next()) {

					result = true;
				}

			}
		} catch (Exception e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}*/

		return result;
	}

	@Override
	public List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) throws IBSException {
		List<CreditCardTransaction> creditCardsList = new ArrayList<>();

		/*try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement(SqlQueries.SELECT_DATA_FROM_CREDIT_TRANSACTION)) {

			LocalDateTime fromDate1 = LocalDateTime.now().minusDays(days);
			LocalDateTime currentDate1 = LocalDateTime.now();
			Timestamp timestamp1 = Timestamp.valueOf(fromDate1);
			Timestamp timestamp2 = Timestamp.valueOf(currentDate1);
			preparedStatement.setTimestamp(1, timestamp1);
			preparedStatement.setTimestamp(2, timestamp2);
			preparedStatement.setBigDecimal(3, new BigDecimal(creditCardNumber));

			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				while (resultSet.next()) {
					CreditCardTransaction credTran = new CreditCardTransaction();
					//credTran.setCreditCardNumber(resultSet.getBigDecimal("Credit_Card_Num").toBigInteger());
					credTran.setAmount(resultSet.getBigDecimal("amount"));
					credTran.setTransactionid(resultSet.getBigDecimal("credit_Trans_Id").toBigInteger());
					credTran.setDescription(resultSet.getString("description"));
					credTran.setDateOfTran(resultSet.getTimestamp("Date_Of_trans").toLocalDateTime());
					credTran.setUCI(resultSet.getBigDecimal("UCI").toBigInteger());
					creditCardsList.add(credTran);

				}

			} catch (Exception e) {

				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
*/
		return creditCardsList;
	}

	@Override
	public BigInteger getCreditCardNumber(String transactionId) throws IBSException {
		BigInteger creditCardNum = null;
		/*String sql = SqlQueries.GET_CREDIT_CARD_NUMBER;
		
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			preparedStatement.setString(1, transactionId);

			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				while (resultSet.next()) {

					creditCardNum = resultSet.getBigDecimal("credit_Card_num").toBigInteger();

				}

			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);

			}
		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}*/
		return creditCardNum;

	}

	@Override
	public BigInteger getCMUci(String transactionId) throws IBSException {
		BigInteger creditCardUci = null;
		/*try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.GET_CM_UCI)) {
			preparedStatement.setString(1, transactionId);

			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				while (resultSet.next()) {

					creditCardUci = resultSet.getBigDecimal("UCI").toBigInteger();

				}

			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);

			}
		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}*/
		return creditCardUci;
	}

}
