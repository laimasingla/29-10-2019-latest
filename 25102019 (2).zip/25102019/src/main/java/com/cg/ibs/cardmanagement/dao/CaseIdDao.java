package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface CaseIdDao {

	String getNewType(String queryId) throws IBSException;

	void setQueryStatus(String queryId, String newStatus) throws IBSException;

	boolean verifyQueryId(String queryId) throws IBSException;
	void requestCreditCardLost(CaseIdBean caseIdObj, BigInteger creditCardNumber) throws IBSException;
	void requestCreditCardUpgrade(CaseIdBean caseIdObj, BigInteger creditCardNumber) throws IBSException;
	List<CaseIdBean> viewAllQueries() throws IBSException;
	void raiseCreditMismatchTicket(CaseIdBean caseIdObj, String transactionId) throws IBSException;

	String getCustomerReferenceId(CaseIdBean caseIdObj, String customerReferenceId) throws IBSException;

	void requestDebitCardUpgrade(CaseIdBean caseIdObj, BigInteger debitCardNumber) throws IBSException;

	void requestDebitCardLost(CaseIdBean caseIdObj, BigInteger debitCardNumber) throws IBSException;
	void newDebitCard(CaseIdBean caseIdObj, BigInteger accountNumber) throws IBSException;
	
	void raiseDebitMismatchTicket(CaseIdBean caseIdObj, String transactionId) throws IBSException;
	void newCreditCard(CaseIdBean caseIdObjId) throws IBSException;
	
	BigInteger getNewUCI(String queryId) throws IBSException;
}
