package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CaseIdDaoImpl implements CaseIdDao {

	private EntityManager entityManager;
	private EntityTransaction entityTransaction;

	public CaseIdDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
		entityTransaction = entityManager.getTransaction();
	}

	@Override
	public boolean verifyQueryId(String queryId) throws IBSException {

		boolean result = false;

		CaseIdBean d = entityManager.find(CaseIdBean.class, queryId);

		if (d != null)
			result = true;

		return result;

	}

	@Override
	public List<CaseIdBean> viewAllQueries() throws IBSException {

		TypedQuery<CaseIdBean> query = entityManager.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST,
				CaseIdBean.class);
		List<CaseIdBean> listOfQueries = query.getResultList();

		return listOfQueries;
	}

	@Override
	public void setQueryStatus(String queryId, String newStatus) throws IBSException {

		CaseIdBean query = entityManager.find(CaseIdBean.class, queryId);
		if (query != null) {
			query.setStatusOfServiceRequest(newStatus);
			entityTransaction.begin();
			entityManager.merge(query);
			entityTransaction.commit();

		}

	}

	@Override
	public String getNewType(String queryId) throws IBSException {

		CaseIdBean caseId = entityManager.find(CaseIdBean.class, queryId);

		return caseId.getDefineServiceRequest();
	}

	@Override
	public void requestCreditCardUpgrade(CaseIdBean caseIdObj, BigInteger creditCardNumber) throws IBSException {
		entityTransaction.begin();
		entityManager.persist(caseIdObj);
		entityTransaction.commit();

	}

	@Override
	public String getCustomerReferenceId(CaseIdBean caseIdObj, String customerReferenceId) throws IBSException {

		String custReferenceStatus = null;
		/*
		 * try (Connection connection =
		 * ConnectionProvider.getInstance().getConnection(); PreparedStatement
		 * preparedStatement = connection
		 * .prepareStatement(SqlQueries.GET_CUSTOMER_REFERENCE_ID)) {
		 * preparedStatement.setString(1, customerReferenceId);
		 * 
		 * try (ResultSet resultSet = preparedStatement.executeQuery()) {
		 * 
		 * while (resultSet.next()) {
		 * 
		 * custReferenceStatus = resultSet.getString("status_of_query");
		 * 
		 * }
		 * 
 		 * } catch (Exception e) { throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		 * 
		 * } } catch (Exception e) { throw new
		 * IBSException(ErrorMessages.INTERNAL_ERROR); }
		 */
		return custReferenceStatus;

	}

	@Override
	public void raiseCreditMismatchTicket(CaseIdBean caseIdObj, String transactionId) throws IBSException {
		
		entityTransaction.begin();
		entityManager.persist(caseIdObj);
		entityTransaction.commit();

	}

	@Override
	public void requestCreditCardLost(CaseIdBean caseIdObj, BigInteger creditCardNumber) throws IBSException {
		/*
		 * try (Connection connection =
		 * ConnectionProvider.getInstance().getConnection(); PreparedStatement
		 * preparedStatement = connection
		 * .prepareStatement(SqlQueries.REQUEST_CREDIT_CARD_LOST);) {
		 * 
		 * preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
		 * preparedStatement.setDate(2,
		 * java.sql.Date.valueOf(caseIdObj.getCaseTimeStamp().toLocalDate()));
		 * preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());
		 * 
		 * preparedStatement.setBigDecimal(4, new BigDecimal(caseIdObj.getUCI()));
		 * preparedStatement.setString(5, caseIdObj.getDefineServiceRequest());
		 * 
		 * preparedStatement.setBigDecimal(6, new
		 * BigDecimal(caseIdObj.getCardNumber())); preparedStatement.setString(7,
		 * caseIdObj.getCustomerReferenceId()); preparedStatement.executeUpdate();
		 * 
		 * } catch (SQLException | IOException e) { throw new
		 * IBSException(ErrorMessages.INTERNAL_ERROR);
		 * 
		 * }
		 */
	}

	@Override
	public void requestDebitCardUpgrade(CaseIdBean caseIdObj, BigInteger debitCardNumber) throws IBSException {

		entityTransaction.begin();
		entityManager.persist(caseIdObj);
		entityTransaction.commit();

	}

	@Override
	public void requestDebitCardLost(CaseIdBean caseIdObj, BigInteger debitCardNumber) throws IBSException {
		/*
		 * try (Connection connection =
		 * ConnectionProvider.getInstance().getConnection(); PreparedStatement
		 * preparedStatement = connection
		 * .prepareStatement(SqlQueries.REQUEST_DEBIT_CARD_LOST);) {
		 * 
		 * preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
		 * preparedStatement.setDate(2,
		 * java.sql.Date.valueOf(caseIdObj.getCaseTimeStamp().toLocalDate()));
		 * 
		 * preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());
		 * preparedStatement.setBigDecimal(4, new
		 * BigDecimal(caseIdObj.getAccountNumber()));
		 * 
		 * preparedStatement.setBigDecimal(5, new BigDecimal(caseIdObj.getUCI()));
		 * preparedStatement.setString(6, caseIdObj.getDefineServiceRequest());
		 * 
		 * preparedStatement.setBigDecimal(7, new
		 * BigDecimal(caseIdObj.getCardNumber())); preparedStatement.setString(8,
		 * caseIdObj.getCustomerReferenceId());
		 * 
		 * preparedStatement.executeUpdate(); preparedStatement.close();
		 * 
		 * } catch (SQLException | IOException e) { throw new
		 * IBSException(ErrorMessages.INTERNAL_ERROR);
		 */

	}

	@Override
	public void raiseDebitMismatchTicket(CaseIdBean caseIdObj, String transactionId) throws IBSException {
		/*
		 * try (Connection connection =
		 * ConnectionProvider.getInstance().getConnection(); PreparedStatement
		 * preparedStatement = connection
		 * .prepareStatement(SqlQueries.REQUEST_DEBIT_MISMATCH_TICKET)) {
		 * 
		 * preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
		 * preparedStatement.setDate(2,
		 * java.sql.Date.valueOf(caseIdObj.getCaseTimeStamp().toLocalDate()));
		 * preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());
		 * 
		 * preparedStatement.setBigDecimal(4, new
		 * BigDecimal(caseIdObj.getAccountNumber()));
		 * 
		 * preparedStatement.setBigDecimal(5, new BigDecimal(caseIdObj.getUCI()));
		 * preparedStatement.setString(6, caseIdObj.getDefineServiceRequest());
		 * 
		 * preparedStatement.setBigDecimal(7, new
		 * BigDecimal(caseIdObj.getCardNumber())); preparedStatement.setString(8,
		 * caseIdObj.getCustomerReferenceId()); preparedStatement.executeUpdate();
		 * 
		 * } catch (SQLException | IOException e) { throw new
		 * IBSException(ErrorMessages.INTERNAL_ERROR);
		 * 
		 * }
		 */
	}

	@Override
	public void newDebitCard(CaseIdBean caseIdObj, BigInteger accountNumber) throws IBSException {

		entityTransaction.begin();
		entityManager.persist(caseIdObj);
		entityTransaction.commit();
	}

	@Override
	public BigInteger getNewUCI(String queryId) throws IBSException {
		BigInteger uci = null;
		/*
		 * try (Connection connection =
		 * ConnectionProvider.getInstance().getConnection(); PreparedStatement
		 * preparedStatement =
		 * connection.prepareStatement(SqlQueries.GET_CREDIT_CARD_UCI);) {
		 * preparedStatement.setString(1, queryId); try (ResultSet resultSet =
		 * preparedStatement.executeQuery()) { while (resultSet.next()) { uci =
		 * resultSet.getBigDecimal("uci").toBigInteger(); } } } catch (SQLException |
		 * IOException e) { throw new IBSException(ErrorMessages.INTERNAL_ERROR); }
		 */
		return uci;
	}

	@Override
	public void newCreditCard(CaseIdBean caseIdObj) throws IBSException {
		/*
		 * try (Connection connection =
		 * ConnectionProvider.getInstance().getConnection(); PreparedStatement
		 * preparedStatement =
		 * connection.prepareStatement(SqlQueries.APPLY_NEW_CREDIT_CARD)) {
		 * 
		 * preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
		 * preparedStatement.setDate(2,
		 * java.sql.Date.valueOf(LocalDateTime.now().toLocalDate()));
		 * preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());
		 * preparedStatement.setBigDecimal(4, new BigDecimal(caseIdObj.getUCI()));
		 * preparedStatement.setString(5, caseIdObj.getDefineServiceRequest());
		 * preparedStatement.setString(6, caseIdObj.getCustomerReferenceId());
		 * preparedStatement.executeUpdate();
		 * 
		 * } catch (SQLException | IOException e) { //
		 * log.error(Arrays.toString(e.getStackTrace())); throw new
		 * IBSException(ErrorMessages.INTERNAL_ERROR);
		 * 
		 * }
		 * 
		 * }
		 */

	}
}
