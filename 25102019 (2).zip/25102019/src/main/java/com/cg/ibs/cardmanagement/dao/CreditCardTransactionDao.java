package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface CreditCardTransactionDao {
	boolean verifyCreditTransactionId(String transactionId) throws IBSException;

	List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) throws IBSException;

	BigInteger getCMUci(String transactionId) throws IBSException;
	BigInteger getCreditCardNumber(String transactionId) throws IBSException;

}
